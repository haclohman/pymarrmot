% Reads forcing data and parameter values from file, then runs models.

% Assumptions:
% - MARRMoT code added to Matlab path

%% 0. Setup
% Ensure MARRMoT is available
marrmot_path = "/Users/wmk934/code/marrmot/MARRMoT";
add_this = genpath(marrmot_path);
addpath(add_this);
clear marrmot_path add_this

% Ensure we're in a known directory so that the relative imports work
cd '/Users/wmk934/data/marrmot_pymarrmot_checks'

% Set the forcing file
forcing_file = "testing_data/c08194200.csv";

% Set the parameter file
parameter_file = "testing_parameters/par_ranges_5th_percentile.csv";

% Set the output folder
output_folder = "simulations/p05";
experiment = "p05"; % prefix for simulation file

%% 1. Prepare data
% Load the forcing data
data = readtable(forcing_file);

% Create a climatology data input structure. 
% NOTE: the names of all structure fields are hard-coded in each model
% file. These should not be changed.
input_climatology.precip   = data.P_mm_d_;   % Daily data: P rate  [mm/d]
input_climatology.temp     = data.T_oC_;     % Daily data: mean T  [degree C]
input_climatology.pet      = data.PET_mm_d_; % Daily data: Ep rate [mm/d]
input_climatology.delta_t  = 1;              % time step size of the inputs: 1 [d]

% Load the parameters
parameters_all = readmatrix(parameter_file);
parameters_all(1,:) = []; % first line just contains parameter indices (1:N)

%% 2. Define the model settings
% Code below prints the model files and lists them so we can easily copy
% them into model_list below.
%model_files = dir("/Users/wmk934/code/marrmot/MARRMoT/Models/Model files");
%model_files(1:3,:) = []; % removes '.','..', 'MARRMoT_model'
%model_files(end,:) = []; % removes 'm_nn_template_pp_ss.m'
%for i = 1:length(model_files)
%    formattedStr = sprintf("'%s',...", model_files(i).name(1:end-2));
%    disp(formattedStr);
%end

model_list  = {'m_01_collie1_1p_1s',...
                'm_02_wetland_4p_1s',...
                'm_03_collie2_4p_1s',...
                'm_04_newzealand1_6p_1s',...
                'm_05_ihacres_7p_1s',...
                'm_06_alpine1_4p_2s',...
                'm_07_gr4j_4p_2s',...
                'm_08_us1_5p_2s',...
                'm_09_susannah1_6p_2s',...
                'm_10_susannah2_6p_2s',...
                'm_11_collie3_6p_2s',...
                'm_12_alpine2_6p_2s',...
                'm_13_hillslope_7p_2s',...
                'm_14_topmodel_7p_2s',...
                'm_15_plateau_8p_2s',...
                'm_16_newzealand2_8p_2s',...
                'm_17_penman_4p_3s',...
                'm_18_simhyd_7p_3s',...
                'm_19_australia_8p_3s',...
                'm_20_gsfb_8p_3s',...
                'm_21_flexb_9p_3s',...
                'm_22_vic_10p_3s',...
                'm_23_lascam_24p_3s',...
                'm_24_mopex1_5p_4s',...
                'm_25_tcm_6p_4s',...
                'm_26_flexi_10p_4s',...
                'm_27_tank_12p_4s',...
                'm_28_xinanjiang_12p_4s',...
                'm_29_hymod_5p_5s',...
                'm_30_mopex2_7p_5s',...
                'm_31_mopex3_8p_5s',...
                'm_32_mopex4_10p_5s',...
                'm_33_sacramento_11p_5s',...
                'm_34_flexis_12p_5s',...
                'm_35_mopex5_12p_5s',...
                'm_36_modhydrolog_15p_5s',...
                'm_37_hbv_15p_5s',...
                'm_38_tank2_16p_5s',...
                'm_39_mcrm_16p_5s',...
                'm_40_smar_8p_6s',...
                'm_41_nam_10p_6s',...
                'm_42_hycymodel_12p_6s',...
                'm_43_gsmsocont_12p_6s',...
                'm_44_echo_16p_6s',...
                'm_45_prms_18p_7s',...
                'm_46_classic_12p_8s',...
                'm_47_IHM19_16p_4s'};

%% 3. Define the solver settings  
% Create a solver settings data input structure. 
% NOTE: the names of all structure fields are hard-coded in each model
% file. These should not be changed.
input_solver_opts.resnorm_tolerance = 0.1;                                       % Root-finding convergence tolerance
input_solver_opts.resnorm_maxiter   = 6;                                           % Maximum number of re-runs
% these are the same settings that run by default if no settings are given

%% 4. Run the models
for i = 1:length(model_list)
    
    % Define the current model
    model = model_list{i};

    % Display progress
    disp(['Now starting model ',model,'.'])

    % Create a model object
    m = feval(model);

    % Find number of stores and parameters
    numPar      = m.numParams;
    numStore    = m.numStores;

    % Specify parameters
    parameter_row = parameters_all(i,:); % will include NaN for most models
    input_theta = parameter_row(~isnan(parameter_row));
    if length(input_theta) ~= numPar
        disp([' - WARNING: incorrect number of parameters found for ',model,'. Skipping.'])
    end

    % Set the inital storages
    input_s0    = ones(numStore,1);

    % Run the model
    [output_ex,...                                                             % Fluxes leaving the model: simulated flow (Q) and evaporation (Ea)
     output_in,...                                                             % Internal model fluxes
     output_ss ,...                                                            % Internal storages
     output_waterbalance] = ...                                                % Water balance check              
                   m.get_output(...                                            % Model method to run and return all outputs
                                input_climatology,...                          % Time series of climatic fluxes in simulation period
                                input_s0,...                                   % Initial storages
                                input_theta,...                                % Parameter set.
                                input_solver_opts);                            % Options for numerical solving of ODEs

    % Store the results in a matrix we can save to CSV
    csv_table = table(data.datenum, 'VariableNames',{'date'});
    outputs = {'output_ex','output_in','output_ss'};
    field_prefixes = {'ex','in','ss'};
    for s = 1:3
        tmp_output = eval(outputs{s}); % access the different output structures
        fields = fieldnames(tmp_output); % find the simulated variables
        for f = 1:length(fields)
            field = fields{f};
            tmp_sim = tmp_output.(field);
            if size(tmp_sim) == [1,7670] % ensure the vector is oriented correctly
                tmp_sim = tmp_sim';
            end
            column_name = sprintf("%s_%s",field_prefixes{s},field);
            csv_table = addvars(csv_table,tmp_sim,'NewVariableNames',column_name);
        end
    end

    % Save the results
    simulation_file = sprintf("%s_sims_%s.csv",experiment,model);
    simulation_path = sprintf("%s/%s", output_folder, simulation_file);
    writetable(csv_table, simulation_path);
    
end














